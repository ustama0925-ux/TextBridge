package jp.textbridge.app;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.*;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.EncodeHintType;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

public class MainActivity extends Activity {
    private LinearLayout editorPane, qrPane;
    private EditText input;
    private TextView countView, pageLabel, modeInfo;
    private ImageView qrImage;
    private Spinner sizeSpinner;
    private final List<String> chunks = new ArrayList<>();
    private int page = 0;
    private float originalBrightness = -1f;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
    }

    private TextView text(String s, int sp, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s); v.setTextSize(sp); v.setTextColor(Color.rgb(23,32,42));
        if (bold) v.setTypeface(null, android.graphics.Typeface.BOLD);
        return v;
    }

    private Button button(String label) {
        Button b = new Button(this); b.setText(label); b.setAllCaps(false);
        return b;
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this); r.setOrientation(LinearLayout.HORIZONTAL); r.setGravity(Gravity.CENTER_VERTICAL);
        return r;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(244,246,248));
        TextView header = text("Text Bridge", 22, true); header.setTextColor(Color.WHITE); header.setBackgroundColor(Color.rgb(17,24,39)); header.setPadding(dp(18),dp(16),dp(18),dp(16));
        root.addView(header, new LinearLayout.LayoutParams(-1,-2));

        ScrollView scroll = new ScrollView(this);
        LinearLayout body = new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL); body.setPadding(dp(14),dp(14),dp(14),dp(18));
        scroll.addView(body); root.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));

        editorPane = new LinearLayout(this); editorPane.setOrientation(LinearLayout.VERTICAL);
        body.addView(editorPane, new LinearLayout.LayoutParams(-1,-2));
        editorPane.addView(text("私用スマホ → 会社スマホへ、テキストをQRで渡します", 16, true));
        TextView note = text("通信・ログイン不要。会社スマホ側は標準カメラで読み取り、Teamsへ貼り付けます。", 13, false); note.setPadding(0,dp(6),0,dp(10)); editorPane.addView(note);

        input = new EditText(this); input.setHint("ChatGPT等で作成した文章をここに貼り付け"); input.setGravity(Gravity.TOP); input.setMinLines(9); input.setTextSize(15); input.setBackgroundColor(Color.WHITE); input.setPadding(dp(12),dp(12),dp(12),dp(12));
        editorPane.addView(input, new LinearLayout.LayoutParams(-1,-2));
        countView = text("0文字 / 0 bytes", 12, false); countView.setPadding(0,dp(5),0,dp(6)); editorPane.addView(countView);
        input.addTextChangedListener(new TextWatcher(){ public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int b,int c){updateCount();} public void afterTextChanged(Editable e){} });

        LinearLayout actions = row();
        Button paste = button("クリップボードから貼付"); Button clear = button("消去");
        actions.addView(paste,new LinearLayout.LayoutParams(0,-2,1)); actions.addView(clear,new LinearLayout.LayoutParams(0,-2,1)); editorPane.addView(actions);
        paste.setOnClickListener(v -> pasteClipboard()); clear.setOnClickListener(v -> input.setText(""));

        TextView densityLabel = text("QRの読み取りやすさ", 14, true); densityLabel.setPadding(0,dp(12),0,dp(4)); editorPane.addView(densityLabel);
        sizeSpinner = new Spinner(this);
        String[] choices = {"読み取り優先（約500 bytes/枚）","標準（約800 bytes/枚）","少ない枚数（約1100 bytes/枚）"};
        ArrayAdapter<String> ad = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, choices); sizeSpinner.setAdapter(ad); sizeSpinner.setSelection(1); editorPane.addView(sizeSpinner);
        modeInfo = text("迷ったら『標準』。読み取りにくければ『読み取り優先』に戻してください。",12,false); modeInfo.setPadding(0,dp(2),0,dp(10)); editorPane.addView(modeInfo);

        Button make = button("QRを作成"); make.setTextSize(18); make.setPadding(0,dp(14),0,dp(14)); editorPane.addView(make,new LinearLayout.LayoutParams(-1,-2)); make.setOnClickListener(v -> makeQrPages());

        qrPane = new LinearLayout(this); qrPane.setOrientation(LinearLayout.VERTICAL); qrPane.setVisibility(View.GONE); qrPane.setGravity(Gravity.CENTER_HORIZONTAL); body.addView(qrPane,new LinearLayout.LayoutParams(-1,-2));
        pageLabel = text("QR 1/1",22,true); pageLabel.setGravity(Gravity.CENTER); qrPane.addView(pageLabel,new LinearLayout.LayoutParams(-1,-2));
        TextView scanHint = text("会社スマホのカメラをQRに向けて読み取ってください",14,false); scanHint.setGravity(Gravity.CENTER); scanHint.setPadding(0,dp(4),0,dp(8)); qrPane.addView(scanHint);
        qrImage = new ImageView(this); qrImage.setBackgroundColor(Color.WHITE); qrImage.setAdjustViewBounds(true); qrImage.setScaleType(ImageView.ScaleType.FIT_CENTER); qrPane.addView(qrImage,new LinearLayout.LayoutParams(-1,dp(430)));

        LinearLayout nav = row();
        Button prev = button("◀ 前へ"); Button next = button("次へ ▶");
        prev.setTextSize(17); next.setTextSize(17); nav.addView(prev,new LinearLayout.LayoutParams(0,dp(62),1)); nav.addView(next,new LinearLayout.LayoutParams(0,dp(62),1)); qrPane.addView(nav,new LinearLayout.LayoutParams(-1,-2));
        prev.setOnClickListener(v -> { if(page>0){page--; renderPage();} }); next.setOnClickListener(v -> { if(page<chunks.size()-1){page++; renderPage();} });
        Button back = button("文章入力へ戻る"); back.setPadding(0,dp(12),0,dp(12)); qrPane.addView(back,new LinearLayout.LayoutParams(-1,-2)); back.setOnClickListener(v -> showEditor());

        TextView sec = text("情報セキュリティ: QRも情報移送手段です。所属組織の規程に従い、機密・未公表・個人情報の移送には使用しないでください。",12,false); sec.setPadding(0,dp(16),0,0); body.addView(sec);
        setContentView(root);
    }

    private void pasteClipboard() {
        ClipboardManager cm=(ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
        if(cm!=null && cm.hasPrimaryClip() && cm.getPrimaryClip().getItemCount()>0){ CharSequence s=cm.getPrimaryClip().getItemAt(0).coerceToText(this); input.setText(s); input.setSelection(input.length()); }
        else Toast.makeText(this,"クリップボードにテキストがありません",Toast.LENGTH_SHORT).show();
    }

    private void updateCount(){ String s=input.getText().toString(); countView.setText(s.codePointCount(0,s.length())+"文字 / "+s.getBytes(StandardCharsets.UTF_8).length+" bytes"); }

    private int selectedBytes(){ int p=sizeSpinner.getSelectedItemPosition(); return p==0?500:(p==2?1100:800); }

    private void makeQrPages() {
        String s=input.getText().toString(); if(s.trim().isEmpty()){Toast.makeText(this,"文章を貼り付けてください",Toast.LENGTH_SHORT).show();return;}
        chunks.clear(); int max=selectedBytes(); StringBuilder cur=new StringBuilder(); int bytes=0;
        for(int i=0;i<s.length();){ int cp=s.codePointAt(i); String ch=new String(Character.toChars(cp)); int b=ch.getBytes(StandardCharsets.UTF_8).length;
            if(bytes+b>max && cur.length()>0){chunks.add(cur.toString());cur.setLength(0);bytes=0;}
            cur.append(ch); bytes+=b; i+=Character.charCount(cp);
        }
        if(cur.length()>0) chunks.add(cur.toString());
        page=0; editorPane.setVisibility(View.GONE); qrPane.setVisibility(View.VISIBLE); getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); maximizeBrightness(); renderPage();
    }

    private String payloadFor(int idx) { return "【TextBridge " + (idx+1) + "/" + chunks.size() + "】\n" + chunks.get(idx); }

    private void renderPage() {
        pageLabel.setText("QR "+(page+1)+" / "+chunks.size());
        try { qrImage.setImageBitmap(makeQr(payloadFor(page), 1000)); }
        catch(Exception e){ Toast.makeText(this,"QR作成エラー: "+e.getMessage(),Toast.LENGTH_LONG).show(); }
    }

    private Bitmap makeQr(String data, int size) throws WriterException {
        Map<EncodeHintType,Object> hints=new EnumMap<>(EncodeHintType.class); hints.put(EncodeHintType.CHARACTER_SET,"UTF-8"); hints.put(EncodeHintType.ERROR_CORRECTION, ErrorCorrectionLevel.M); hints.put(EncodeHintType.MARGIN,2);
        BitMatrix m=new QRCodeWriter().encode(data, BarcodeFormat.QR_CODE,size,size,hints); Bitmap bmp=Bitmap.createBitmap(size,size,Bitmap.Config.ARGB_8888); int[] px=new int[size*size]; for(int y=0;y<size;y++)for(int x=0;x<size;x++)px[y*size+x]=m.get(x,y)?Color.BLACK:Color.WHITE; bmp.setPixels(px,0,size,0,0,size,size); return bmp;
    }

    private void maximizeBrightness(){ WindowManager.LayoutParams lp=getWindow().getAttributes(); originalBrightness=lp.screenBrightness; lp.screenBrightness=1f; getWindow().setAttributes(lp); }
    private void restoreBrightness(){ if(originalBrightness>=0){WindowManager.LayoutParams lp=getWindow().getAttributes(); lp.screenBrightness=originalBrightness; getWindow().setAttributes(lp); originalBrightness=-1f;} }
    private void showEditor(){ restoreBrightness(); getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); qrPane.setVisibility(View.GONE); editorPane.setVisibility(View.VISIBLE); }
    @Override public void onBackPressed(){ if(qrPane.getVisibility()==View.VISIBLE) showEditor(); else super.onBackPressed(); }
    @Override protected void onDestroy(){restoreBrightness(); super.onDestroy();}
    private int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+0.5f);}    
}
