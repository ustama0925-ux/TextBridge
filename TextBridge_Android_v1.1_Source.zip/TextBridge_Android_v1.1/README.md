# Text Bridge Android v1.1

私用Androidスマホ上のテキストをQR化し、会社Androidスマホの標準カメラで読み取るための**送信専用**アプリです。

## 使い方
1. ChatGPT等で文章をコピー。
2. Text Bridgeを起動し「クリップボードから貼付」。
3. 「標準（約800 bytes/枚）」のまま「QRを作成」。
4. 会社スマホの標準カメラでQRを読み、表示されたテキストをコピーしてTeamsへ貼り付け。
5. 複数枚なら 1/4 → 2/4 → ... の順に同じ操作を行う。
6. 会社PCのTeamsから利用する。

QR本文の先頭に `【TextBridge 1/4】` のような連番が入ります。Copilot/ChatGPTへ渡す場合は、連番付きのまま「順番に連結して扱って」と指示しても構いません。

## QR密度
- 読み取り優先: 約500 UTF-8 bytes/枚
- 標準: 約800 UTF-8 bytes/枚（初期値）
- 少ない枚数: 約1100 UTF-8 bytes/枚

日本語は通常1文字3 bytes前後なので、標準設定で概ね200〜270文字/枚が目安です。機種・照明・画面サイズによって読み取りやすさは変わります。

## プライバシー/権限
Manifestでは INTERNET / CAMERA / STORAGE 権限を要求していません。アプリはQR生成専用です。会社側にはアプリのインストールは不要です。

QRも情報移送手段です。所属組織の情報セキュリティ規程に従い、機密情報・未公表情報・個人情報等の移送には使用しないでください。

## GitHubでAPKを自動生成する手順
このプロジェクトの中身をGitHubリポジトリ `TextBridge` のルートへアップロードしてmainへCommitすると、GitHub Actionsが自動的にAPKをビルドします。

成功すると `Releases` に **Text Bridge Android v1.1** が作られ、`TextBridge-Android-v1.1.apk` が添付されます。

GitHub Actionsが初回無効の場合は、リポジトリの `Actions` タブを開いて有効化し、`Build Android APK` → `Run workflow` を実行してください。
